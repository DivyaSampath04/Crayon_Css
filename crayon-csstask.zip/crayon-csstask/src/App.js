import React , {Component} from 'react';

import './App.css';

class App extends Component {
  render() {

  return (
    <div>
    < div>
  <div className="column" >
    <div className = "title" style = {{backgroundColor : "lightblue"}}>Chicken</div>
    <p>Chicken is the most common type of poultry in the world. Owing to the relative ease and low cost of raising them in comparison to animals such as cattle or hogs, chickens have become prevalent throughout the cuisine of cultures around the world, and their meat has been variously adapted to regional tastes</p>
  </div>
 
  <div className="column" >
  <div className = "title" style = {{backgroundColor : "lightgreen"}}>Beef</div>
    <p>Beef is the culinary name for meat from cattle, particularly skeletal muscle. Humans have been eating beef since prehistoric times. Beef is a source of high-quality protein and nutrients</p>
  </div>
 
  <div className="column" >
  <div className = "title" style = {{backgroundColor : "lightpink"}}>Sushi</div>
    <p>Sushi is a Japanese dish of prepared vinegared rice, usually with some sugar and salt, accompanying a variety of ingredients, such as seafood, vegetables, and occasionally tropical fruit</p>
  </div>
 
  
</div>
    </div>
  );
}
}

export default App;
